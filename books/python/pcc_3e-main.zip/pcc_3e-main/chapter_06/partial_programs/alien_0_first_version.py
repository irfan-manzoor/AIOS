alien_0 = {'color': 'green', 'points': 5}

print(alien_0['color'])
print(alien_0['points'])
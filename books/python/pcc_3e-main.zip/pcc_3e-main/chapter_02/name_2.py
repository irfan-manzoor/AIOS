name = "Ada Lovelace"
print(name.upper())
print(name.lower())
message = input("Tell me something, and I will repeat it back to you: ")
print(message)
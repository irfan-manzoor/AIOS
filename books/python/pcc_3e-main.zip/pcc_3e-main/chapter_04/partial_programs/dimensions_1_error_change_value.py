dimensions = (200, 50)
dimensions[0] = 250